<?php

namespace App\Http\Controllers;

use App\Models\SelloutDistributor;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SelloutDistributorController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $limit = min(max($request->integer('limit', 300), 1), 1000);

        $query = SelloutDistributor::with(['distributor:id,code,name', 'depo:id,code,name', 'area:id,code,name', 'brand:id,code,name'])
            ->when($request->filled('period'), fn ($q) => $q->where('period', trim($request->period)))
            ->when($request->filled('depo_id'), fn ($q) => $q->where('depo_id', $request->depo_id))
            ->when($request->filled('area_id'), fn ($q) => $q->where('area_id', $request->area_id))
            ->when($request->filled('is_out_of_area'), fn ($q) => $q->where('is_out_of_area', $request->boolean('is_out_of_area')))
            ->when($request->filled('q'), function ($q) use ($request) {
                $term = trim($request->q);
                $q->where(function ($sub) use ($term) {
                    $sub->where('faktur', 'like', "%{$term}%")
                        ->orWhere('customer_code', 'like', "%{$term}%")
                        ->orWhere('customer_name', 'like', "%{$term}%")
                        ->orWhere('item_name', 'like', "%{$term}%")
                        ->orWhere('kota_kab', 'like', "%{$term}%");
                });
            })
            ->latest('id')
            ->limit($limit);

        return response()->json($query->get());
    }

    public function destroy(SelloutDistributor $selloutDistributor): JsonResponse
    {
        $selloutDistributor->delete();

        return response()->json([
            'message' => 'Data Sell-Out Distributor berhasil dihapus',
        ]);
    }
}
